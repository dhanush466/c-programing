echo "enter a number"
read a
square=`expr $a \* $a`
echo $square
